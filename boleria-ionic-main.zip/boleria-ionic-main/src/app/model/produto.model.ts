export interface Produtos{
    id: number,
    produto: string,
    quantidade: string,
    status: boolean,
    receita: string,
    imagem: string
}